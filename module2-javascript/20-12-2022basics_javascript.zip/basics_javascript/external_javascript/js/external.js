alert('hi i just loading javascript')
window.location='https://www.amazon.in';